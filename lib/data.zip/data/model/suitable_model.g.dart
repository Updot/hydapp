// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'suitable_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SuitableModel _$SuitableModelFromJson(Map<String, dynamic> json) {
  return SuitableModel(
    id: json['id'] as int,
    name: json['name'] as String,
  );
}

Map<String, dynamic> _$SuitableModelToJson(SuitableModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
    };
